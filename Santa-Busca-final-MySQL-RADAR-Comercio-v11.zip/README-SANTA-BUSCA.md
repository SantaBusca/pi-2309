# Santa Busca — versão integrada

Esta versão trabalha em cima da estrutura original do Santa Busca e adiciona as melhorias solicitadas sem substituir a interface por um projeto novo.

## O que foi preservado

- Identidade visual, cores, fontes, botões e estrutura geral.
- Categorias Supermercados, Farmácias e Postos.
- Pesquisa de produtos e estabelecimentos.
- Localização e ordenação por preço/distância.
- Comparação de preços.
- Confirmação de preço.
- Denúncia de preço com comprovante obrigatório.
- Histórico de preços.
- Pontos mensais.
- Notificações e ofertas.
- Ranking e conquistas do usuário.
- Reputação automática dos estabelecimentos.
- Área de estabelecimento separada do painel.
- localStorage como armazenamento do protótipo.

## Alterações desta versão

### Página inicial

A barra de pesquisa agora aparece antes da seção de categorias.

A estrutura continua usando as mesmas áreas existentes:
- `.controlsPanel` para pesquisa/localização.
- `.categorySection` para as três categorias.

A mãozinha `👆` da `.emptyHero`, criada dentro de `render()` em `script.js`, foi mantida separada dos emojis das categorias e recebe somente um movimento visual para orientar o usuário para a área das categorias.

### Estabelecimento

O cadastro e o login continuam em `estabelecimento.html`.

Após cadastro ou login, o estabelecimento é enviado para:

`dashboard-estabelecimento.html`

O dashboard é protegido: sem uma sessão de estabelecimento em `localStorage`, o acesso volta para `estabelecimento.html`.

O painel permite:
- visualizar dados cadastrados;
- editar dados;
- visualizar logo/foto;
- cadastrar produtos;
- editar produtos;
- alterar preço;
- alterar disponibilidade;
- excluir produtos;
- publicar ofertas;
- editar/excluir ofertas;
- sair da conta.

Os produtos novos são persistidos em `localStorage` e entram no catálogo da página principal sem criar produtos fictícios.

### CNPJ

O CNPJ agora possui validação real dos dígitos verificadores.

O campo:
- aceita somente números durante a entrada;
- aplica a máscara `00.000.000/0000-00`;
- remove letras e caracteres indevidos quando digitados ou colados;
- valida a quantidade de 14 dígitos;
- rejeita sequências inválidas como todos os dígitos iguais;
- valida novamente no envio do cadastro;
- também é validado no formulário de edição do dashboard.

O exemplo `12345678000195` é formatado como `12.345.678/0001-95`.

### Outros campos numéricos

A validação respeita o tipo de cada campo.

- Preços: números e separador decimal.
- Coordenadas: números, decimais e sinal negativo.
- CNPJ: máscara e validação própria.
- Nome/endereço: continuam aceitando letras e números quando apropriado.
- E-mail: validação própria de e-mail.

### Pontos

As ações do usuário comum continuam com:
- Confirmar preço → +2 pontos.
- Denunciar preço com comprovante → +5 pontos.

A pontuação é mensal e a mesma ação para o mesmo preço fica bloqueada no mesmo mês.

Estabelecimentos não recebem pontos nem participam do ranking de colaboradores.

### Reputação

A reputação é calculada automaticamente com as denúncias do mês atual:

- 0 → Ótima
- 1 → Atenção
- 2 → Ruim
- 3 ou mais → Muito ruim

A reputação geral de um estabelecimento considera o pior produto denunciado.

### Ranking dos estabelecimentos

O ranking não possui limite fixo de três estabelecimentos.

Todos os estabelecimentos existentes nos dados do sistema aparecem automaticamente, incluindo novos estabelecimentos cadastrados.

A penalização considera o total de denúncias do estabelecimento no mês atual, somando denúncias de todos os produtos.

Regra:

- 0 denúncias → 0 pontos perdidos.
- 1 denúncia → 0 pontos perdidos.
- 2 denúncias → 0 pontos perdidos.
- 3 denúncias → 0 pontos perdidos.
- 4 denúncias → -1 ponto.
- 5 denúncias → -2 pontos.
- 6 denúncias → -3 pontos.

A fórmula usada é:

`pontos perdidos = max(0, denúncias do mês - 3)`

A pontuação exibida no ranking parte de 100 e desconta somente essa penalização.

Isso é separado da reputação do produto. Portanto, um produto pode ficar com reputação "Muito ruim" a partir da 3ª denúncia, enquanto o estabelecimento ainda não perde pontos no ranking até ultrapassar a 3ª denúncia total.

### Correção de bug crítico

Foi encontrado e corrigido um erro fatal de JavaScript que quebrava
`estabelecimento.html` e, por consequência, `dashboard-estabelecimento.html`
(que redireciona para `estabelecimento.html` quando não há sessão):
a função `dropdown()` recebia o **id em texto** do painel (ex.:
`"dias-panel"`) mas tentava chamar `panel.appendChild(...)` diretamente
nessa string, gerando `panel.appendChild is not a function` assim que a
página carregava. Isso interrompia a execução do script inteiro,
quebrando login, cadastro e o dashboard como um todo — mesmo com o
restante do código correto.

Corrigido resolvendo o elemento real (`const panelEl = $(panel)`) antes
de usá-lo. Também foi corrigido o "pulo do cursor" no campo de CNPJ ao
digitar/editar no meio do valor. A sintaxe dos arquivos JavaScript foi
verificada com `node --check`; a execução final com o MySQL local depende
da instalação e dos dados do ambiente da equipe.

### Formatação e revisão

Os arquivos HTML, CSS, JavaScript e JSON foram reorganizados em várias linhas com indentação para facilitar leitura e manutenção.

Foi feita verificação de sintaxe com `node --check` nos arquivos JavaScript.

Também foi feita uma simulação da camada de armazenamento para verificar:
- CNPJ válido/inválido;
- persistência de estabelecimento;
- persistência de produto;
- inclusão de produto no catálogo;
- reputação mensal;
- soma de denúncias por estabelecimento;
- tolerância de 3 denúncias;
- penalização do ranking.

A interface não foi executada em um navegador real neste ambiente, portanto testes visuais de clique, upload e geolocalização ainda devem ser feitos localmente ao abrir o projeto.

## Banco de dados MySQL — versão 2.1

O projeto usa **Node.js + MySQL**. PHP/XAMPP não são necessários.

### Estrutura
- `server.js`: servidor HTTP do Santa Busca e API.
- `api-client.js`: ponte do front-end para a API Node.
- `db.sql`: estrutura do banco MySQL.
- `package.json`: dependência `mysql2`.

### Como executar
1. Tenha o **Node.js 18 ou superior** instalado.
2. O banco `santa_busca` deve existir no MySQL. Se ainda não criou, execute `db.sql` no MySQL Workbench.
3. Abra o terminal na pasta do Santa Busca.
4. Execute `npm install`.
5. Execute `npm start`.
6. Abra `http://localhost:3000`.

### Configuração do MySQL
Por padrão, o servidor usa:
- host: `127.0.0.1`
- porta: `3306`
- usuário: `root`
- senha: vazia
- banco: `santa_busca`

Se sua instalação usa outros dados, defina as variáveis de ambiente `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` e `DB_NAME` antes de iniciar.

### Verificação
Com o servidor ligado, abra `http://localhost:3000/api/api?action=health`. Deve retornar JSON indicando que a API está conectada ao MySQL.

### Segurança
Senhas cadastradas pela API são armazenadas usando `scrypt` com salt, e não em texto puro. Para produção, ainda seria necessário autenticação por sessão/token, HTTPS, controle de permissões e armazenamento externo das imagens.

### Importante
O MySQL Workbench continua sendo usado normalmente para administrar o banco. Ele não precisa executar o projeto; quem executa o Santa Busca é o Node.js.

## Atualização — ferramentas para o comércio

O painel do estabelecimento agora inclui o **Radar do Comércio**, com dados agregados da plataforma:
- produtos mais pesquisados no mês;
- crescimento da procura em relação ao mês anterior;
- demanda não atendida (termos pesquisados sem produto correspondente no catálogo do estabelecimento);
- oportunidades de preço comparando produtos equivalentes;
- visitas ao perfil, buscas que encontraram produtos do estabelecimento, ofertas ativas e preços desatualizados;
- atualização rápida de preço;
- atalho para esgotar/tornar disponível um produto;
- indicador de atualização dos preços no painel e na página pública.

A plataforma registra buscas de forma agregada somente quando o usuário confirma a pesquisa com Enter, evitando contar cada letra digitada. Visualizações do perfil também possuem proteção contra contagens repetidas da mesma sessão em curto intervalo. Não há ranking de pessoas.

A página pública do estabelecimento funciona como um perfil completo, com capa, logotipo, ofertas, catálogo pesquisável, filtros por categoria, disponibilidade, atualização dos preços, informações de funcionamento e atalho de localização.

## Banco de dados

`db.sql` inclui as tabelas do sistema e as chaves estrangeiras, além das novas tabelas:
- `buscas` — pesquisas agregadas usadas pelo Radar do Comércio;
- `visualizacoes_estabelecimentos` — visualizações dos perfis dos estabelecimentos;
- `alertas_preco` — alertas criados por usuários com 26+ pontos no mês;
- `notificacoes_preco` — registros quando um preço atinge o valor-alvo de um alerta.

A tabela `ofertas` possui chave única por `(estabelecimento_id, chave)` para manter a sincronização idempotente.

**Importante:** se o banco `santa_busca` já existe, `CREATE TABLE IF NOT EXISTS` não altera a estrutura das tabelas antigas. Faça backup antes de aplicar mudanças estruturais. Para uma instalação limpa, execute o `db.sql` completo.

## Iniciar sem digitar o endereço

Depois de instalar as dependências com `npm install`, você pode abrir `INICIAR-SANTA-BUSCA.bat`. Ele inicia o Node.js e abre automaticamente `http://localhost:3000` no navegador.

### Abertura das páginas

O painel do estabelecimento e a página pública redirecionam automaticamente para o servidor local quando forem abertos pelo Explorador de Arquivos. O servidor Node precisa estar em execução para acessar o MySQL.
