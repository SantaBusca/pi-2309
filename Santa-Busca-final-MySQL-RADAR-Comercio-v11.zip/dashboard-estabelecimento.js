"use strict";

(function () {
    const S = SantaBuscaStorage;
    const establishment = S.getCurrentEstablishment();

    if (!establishment) {
        window.location.href = "estabelecimento.html";
        return;
    }

    const $ = (id) => document.getElementById(id);

    let editingProduct = null;

    function showMessage(id, message, type = "success") {
        const element = $(id);
        element.textContent = message;
        element.classList.toggle("errorMessage", type === "error");
    }

    function parseDecimal(value, allowNegative = false) {
        const sanitized = S.sanitizeDecimal(
            value,
            allowNegative
        );

        if (sanitized === "" || sanitized === "-" || sanitized === ".") {
            return NaN;
        }

        return Number(sanitized);
    }

    function setupDecimalInput(input) {
        if (!input) {
            return;
        }

        input.addEventListener("input", () => {
            input.value = S.sanitizeDecimal(
                input.value,
                input.dataset.negative === "true"
            );
        });

        input.addEventListener("blur", () => {
            const value = parseDecimal(
                input.value,
                input.dataset.negative === "true"
            );

            if (Number.isFinite(value)) {
                input.value = value.toFixed(2).replace(/\.00$/, "");
            }
        });
    }

    function setupCoordinateInput(input) {
        if (!input) {
            return;
        }

        input.addEventListener("input", () => {
            input.value = input.value
                .split(",")
                .slice(0, 2)
                .map((part) => S.sanitizeDecimal(part, true))
                .join(", ");
        });

        input.addEventListener("blur", () => {
            input.value = input.value
                .split(",")
                .slice(0, 2)
                .map((part) => S.sanitizeDecimal(part, true).trim())
                .join(", ");
        });
    }

    function setupCNPJInput(input) {
        if (!input) {
            return;
        }

        const update = () => {
            S.reformatKeepingCaret(input, S.formatCNPJ);
            $("edit-cnpj-field").classList.toggle(
                "field-error",
                input.value !== "" &&
                !S.validateCNPJ(input.value)
            );
        };

        input.addEventListener("input", update);

        input.addEventListener("blur", () => {
            input.value = S.formatCNPJ(input.value);
            $("edit-cnpj-field").classList.toggle(
                "field-error",
                !S.validateCNPJ(input.value)
            );
        });
    }

    function getProductPriceKey(product) {
        return product.chave || S.priceKey(product.nome, product.marca, establishment.nome);
    }

    function renderSummary() {
        const products = getMyProducts();
        const offers = S.getOffersForEstablishment(establishment);
        const reputation = S.getEstablishmentReputation().find((item) => item.id === establishment.id);
        const stale = products.filter((product) => S.isStale(S.read(S.KEYS.prices, {})[getProductPriceKey(product)])).length;
        const activeOffers = offers.filter((offer) => S.activeOffer(offer.chave));

        $("dashboard-summary").innerHTML = `
            <div class="summaryCard"><strong>${products.length}</strong><span>Produtos</span></div>
            <div class="summaryCard"><strong>${activeOffers.length}</strong><span>Ofertas ativas</span></div>
            <div class="summaryCard"><strong>${reputation?.nivel || "Ótima"}</strong><span>Reputação</span></div>
            <div class="summaryCard ${stale ? "summaryAlert" : ""}"><strong>${stale}</strong><span>Preços desatualizados</span></div>
        `;
    }

    function refreshDashboardData() {
        const latest = S.getCurrentEstablishment();
        if (latest) {
            Object.assign(establishment, latest);
            fillEstablishment();
            renderProducts();
            populateProductSelectors();
            renderOffers();
            renderSummary();
            renderTrustSeal();
        }
    }

    function renderCommerceRadar() {
        const radar = S.getCommerceRadar(establishment);
        const box = $("commerce-radar");
        if (!box || !radar) return;

        const demandHTML = radar.demand.length
            ? radar.demand.map((item) => `
                <article class="radarItem">
                    <span class="radarIcon">${escapeHTML(item.emoji)}</span>
                    <div><strong>${escapeHTML(item.nome)}</strong><small>${escapeHTML(item.marca || "")}</small></div>
                    <b>${item.buscas} busca${item.buscas === 1 ? "" : "s"}</b>
                    ${item.crescimento > 0 ? `<em>↑ ${item.crescimento}%</em>` : item.crescimento < 0 ? `<em>↓ ${Math.abs(item.crescimento)}%</em>` : ""}
                </article>
            `).join("")
            : '<div class="mutedBox">Ainda não há pesquisas suficientes para formar o radar.</div>';

        const unmetHTML = radar.unmet.length
            ? radar.unmet.map((item) => `
                <article class="radarOpportunity">
                    <div><strong>${escapeHTML(item.consulta)}</strong><small>${item.buscas} busca${item.buscas === 1 ? "" : "s"} e nenhum produto seu correspondente.</small></div>
                    <span>💡 Oportunidade</span>
                </article>
            `).join("")
            : '<div class="mutedBox">Nenhuma demanda não atendida identificada até agora.</div>';

        const priceHTML = radar.priceRows.length
            ? radar.priceRows.map((item) => {
                const above = item.diferenca > 0;
                return `
                    <article class="radarOpportunity">
                        <div><strong>${escapeHTML(item.nome)} · ${escapeHTML(item.marca || "")}</strong><small>Seu preço: ${formatPrice(item.atual)} · Média encontrada: ${formatPrice(item.media)}</small></div>
                        <span class="${above ? "priceAbove" : "priceBelow"}">${above ? "+" : "-"}${formatPrice(Math.abs(item.diferenca))}</span>
                    </article>
                `;
            }).join("")
            : '<div class="mutedBox">Ainda não há produtos com comparação suficiente de preços.</div>';

        const alertBanner = radar.unmet.length
            ? `
                <div class="radarAlertBanner">
                    <span class="radarAlertIcon">🔥</span>
                    <div>
                        <strong>${radar.unmet.length} produto${radar.unmet.length === 1 ? "" : "s"} muito procurado${radar.unmet.length === 1 ? "" : "s"} e você ainda não vende.</strong>
                        <small>O mais buscado foi "${escapeHTML(radar.unmet[0].consulta)}" (${radar.unmet[0].buscas} busca${radar.unmet[0].buscas === 1 ? "" : "s"} este mês).</small>
                    </div>
                    <a href="#my-products" class="btn btn-primary dashboardSmallBtn">Cadastrar agora</a>
                </div>
            `
            : "";

        box.innerHTML = `
            ${alertBanner}
            <div class="radarStats">
                <div class="radarStat"><strong>${radar.views}</strong><span>visitas ao seu perfil</span></div>
                <div class="radarStat"><strong>${radar.appearances}</strong><span>buscas que encontraram seus produtos</span></div>
                <div class="radarStat"><strong>${radar.offers}</strong><span>ofertas ativas</span></div>
                <div class="radarStat ${radar.stale ? "radarWarn" : ""}"><strong>${radar.stale}</strong><span>preços desatualizados</span></div>
            </div>

            <div class="radarGrid">
                <article class="radarPanel">
                    <div class="subHeading"><div><h3>🔥 Produtos mais procurados</h3><small>Pesquisas deste mês na plataforma.</small></div></div>
                    <div class="radarList">${demandHTML}</div>
                </article>
                <article class="radarPanel radarHighlight">
                    <div class="subHeading"><div><h3>⚠️ Demanda não atendida</h3><small>O que as pessoas procuram e você ainda não oferece.</small></div></div>
                    <div class="radarList">${unmetHTML}</div>
                </article>
                <article class="radarPanel">
                    <div class="subHeading"><div><h3>💰 Oportunidades de preço</h3><small>Compare seus preços com os encontrados na plataforma.</small></div></div>
                    <div class="radarList">${priceHTML}</div>
                </article>
            </div>
        `;
    }

    function renderTrustSeal() {
        const box = $("trust-seal");
        if (!box) return;

        const reputation = S.getEstablishmentReputation().find((item) => item.id === establishment.id) || { nivel: "Ótima" };
        const publicUrl = `${location.origin}${location.pathname.replace(/dashboard-estabelecimento\.html$/, "")}estabelecimento-publico.html?id=${encodeURIComponent(establishment.id)}`;

        const nivelInfo = {
            "Ótima": { emoji: "🟢", texto: "Estabelecimento confiável — poucas ou nenhuma denúncia este mês." },
            "Atenção": { emoji: "🟡", texto: "Atenção: algumas denúncias este mês. Mantenha seus preços atualizados." },
            "Ruim": { emoji: "🟠", texto: "Reputação em queda. Confira os preços denunciados no mês." },
            "Muito ruim": { emoji: "🔴", texto: "Reputação baixa. Atualize os preços denunciados para recuperar a confiança." }
        }[reputation.nivel] || { emoji: "🟢", texto: "" };

        box.innerHTML = `
            <div class="trustSealBadge">
                <span class="trustSealEmoji">${nivelInfo.emoji}</span>
                <div>
                    <strong>Reputação: ${escapeHTML(reputation.nivel)}</strong>
                    <small>${escapeHTML(nivelInfo.texto)}</small>
                </div>
            </div>
            <div class="trustSealQr">
                <canvas id="trust-seal-canvas"></canvas>
                <small>Aponte a câmera para ver a página do estabelecimento</small>
                <button id="download-qr" class="btn btn-secondary dashboardSmallBtn" type="button">⬇ Baixar QR code</button>
            </div>
        `;

        const canvas = $("trust-seal-canvas");

        if (canvas && typeof QRCode !== "undefined") {
            QRCode.toCanvas(canvas, publicUrl, { width: 160, margin: 1 }, (error) => {
                if (error) {
                    console.warn("Santa Busca: não foi possível gerar o QR code.", error);
                    return;
                }

                $("download-qr")?.addEventListener("click", () => {
                    const link = document.createElement("a");
                    link.download = `santa-busca-${(establishment.nome || "estabelecimento").toLowerCase().replace(/\s+/g, "-")}.png`;
                    link.href = canvas.toDataURL("image/png");
                    link.click();
                });
            });
        } else if (canvas) {
            canvas.replaceWith(document.createTextNode("Não foi possível carregar o gerador de QR code (verifique sua conexão)."));
        }
    }

    function fillEstablishment() {
        $("dash-name").textContent =
            establishment.nome || "Meu estabelecimento";

        $("edit-email").value =
            establishment.email || "";

        $("edit-nome").value =
            establishment.nome || "";

        $("edit-cnpj").value =
            S.formatCNPJ(establishment.cnpj || "");

        $("edit-endereco").value =
            establishment.endereco || "";

        $("edit-coord").value =
            establishment.coordenadas || "";

        $("edit-tipo").value =
            establishment.tipo || "comercio";

        $("edit-abertura").value =
            establishment.abertura || "";

        $("edit-fechamento").value =
            establishment.fechamento || "";

        $("edit-dias").value =
            Array.isArray(establishment.dias)
                ? establishment.dias.join(", ")
                : establishment.dias || "";

        renderImages();
    }

    function readImage(file) {
        return new Promise((resolve, reject) => {
            if (!file) {
                resolve(null);
                return;
            }

            const reader = new FileReader();

            reader.onerror = () =>
                reject(
                    new Error("Não foi possível ler a imagem.")
                );

            reader.onload = (event) =>
                resolve(event.target.result);

            reader.readAsDataURL(file);
        });
    }

    function escapeHtml(value) {
        return String(value ?? "").replace(/[&<>'"]/g, (c) => ({
            "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
        }[c]));
    }

    let imagePreview = {};

    function renderImages(preview = imagePreview) {
        imagePreview = { ...imagePreview, ...preview };
        const container = $("current-images");
        const cover = imagePreview.foto || establishment.foto || "";
        const logo = imagePreview.logo || establishment.logo || "";

        container.innerHTML = `
            <div class="dashboardProfilePreview">
                <div class="dashboardProfileCover">
                    ${cover
                        ? `<img src="${cover}" alt="Capa do estabelecimento">`
                        : `<div class="dashboardCoverFallback">🖼️<span>Foto de capa</span></div>`}
                </div>
                <div class="dashboardProfileIdentity">
                    <div class="dashboardProfileAvatar">
                        ${logo
                            ? `<img src="${logo}" alt="Foto do perfil do estabelecimento">`
                            : `<span>🏪</span>`}
                    </div>
                    <div class="dashboardProfileIdentityText">
                        <strong>${escapeHtml(establishment.nome || "Meu estabelecimento")}</strong>
                        <span>Prévia da página pública</span>
                    </div>
                </div>
            </div>
        `;
    }

    function getMyProducts() {
        return S.getEstablishmentProducts(
            establishment
        );
    }

    function getProductKey(product) {
        return product.chave || S.priceKey(
            product.nome,
            product.marca,
            establishment.nome
        );
    }

    function renderProducts() {
        const products = getMyProducts();
        const container = $("my-products");

        if (!products.length) {
            container.innerHTML = `
                <div class="mutedBox">
                    Este estabelecimento ainda não possui produtos cadastrados.
                    Use "Cadastrar produto" para adicionar o primeiro.
                </div>
            `;
            return;
        }

        container.innerHTML = products
            .map((product) => {
                const price = Number(
                    product.preco
                );

                const isBest = product.disponibilidade !== "esgotado" &&
                    S.isBestRegionalPrice(product.nome, product.marca, price, establishment.nome);

                return `
                    <article class="dashboardListItem">
                        <div>
                            <strong>
                                ${escapeHTML(product.emoji || "📦")}
                                ${escapeHTML(product.nome)}
                            </strong>
                            <small>
                                ${escapeHTML(product.marca || "Sem marca")}
                                · ${escapeHTML(product.unidade || "unidade")}
                            </small>
                            <small>
                                ${Number.isFinite(price)
                                    ? formatPrice(price)
                                    : "Preço não informado"}
                                · ${
                                    product.disponibilidade === "esgotado"
                                        ? "Esgotado"
                                        : "Disponível"
                                }
                            </small>
                            ${isBest ? '<small class="badgeBarato">🏆 Melhor preço da região</small>' : ""}
                            <small>${freshnessLabel(product)}</small>
                        </div>

                        <div class="dashboardListActions">
                            <button
                                class="miniAction"
                                type="button"
                                data-quick-price="${escapeHTML(product.id)}"
                            >
                                ⚡ Preço
                            </button>

                            <button
                                class="miniAction"
                                type="button"
                                data-toggle-stock="${escapeHTML(product.id)}"
                            >
                                ${product.disponibilidade === "esgotado" ? "✓ Disponível" : "⛔ Esgotar"}
                            </button>

                            <button
                                class="miniAction"
                                type="button"
                                data-edit-product="${escapeHTML(product.id)}"
                            >
                                Editar
                            </button>

                            <button
                                class="miniAction dangerBtn"
                                type="button"
                                data-delete-product="${escapeHTML(product.id)}"
                            >
                                Excluir
                            </button>
                        </div>
                    </article>
                `;
            })
            .join("");
    }

    function escapeHTML(value) {
        return String(value ?? "").replace(
            /[&<>"']/g,
            (character) => ({
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#39;"
            }[character])
        );
    }

    function formatPrice(value) {
        return new Intl.NumberFormat("pt-BR", {
            style: "currency",
            currency: "BRL"
        }).format(Number(value));
    }

    function freshnessLabel(product) {
        const meta = S.read(S.KEYS.prices, {})[getProductKey(product)];
        if (!meta?.atualizadoEm) return "⚪ Sem atualização registrada";
        const days = Math.floor((Date.now() - new Date(meta.atualizadoEm).getTime()) / 86400000);
        if (days <= 0) return "🟢 Atualizado hoje";
        if (days === 1) return "🟢 Atualizado ontem";
        if (days < S.STALE_DAYS) return `🟡 Atualizado há ${days} dias`;
        return `🔴 Desatualizado há ${days} dias`;
    }

    function openProductForm(product = null) {
        editingProduct = product;

        $("product-form-wrap").hidden = false;
        $("product-form-title").textContent =
            product
                ? "Editar produto"
                : "Cadastrar produto";

        $("product-id").value =
            product && !product.origemCatalogo
                ? product.id
                : "";

        $("product-name").value =
            product?.nome || "";

        $("product-brand").value =
            product?.marca || "";

        $("product-category").value =
            product?.categoria || "Supermercados";

        $("product-unit").value =
            product?.unidade || "unidade";

        $("product-price").value =
            Number.isFinite(Number(product?.preco))
                ? String(product.preco).replace(".", ",")
                : "";

        $("product-emoji").value =
            product?.emoji || "";

        $("product-availability").value =
            product?.disponibilidade || "disponivel";

        $("product-msg").textContent = "";
        $("product-name").focus();
    }

    function closeProductForm() {
        editingProduct = null;
        $("product-form").reset();
        $("product-id").value = "";
        $("product-category").value = "Supermercados";
        $("product-availability").value = "disponivel";
        $("product-form-wrap").hidden = true;
    }

    function populateProductSelectors() {
        const products = getMyProducts();

        const productOptions = products
            .map(
                (product, index) => `
                    <option value="${index}">
                        ${escapeHTML(product.nome)}
                        · ${escapeHTML(product.marca)}
                    </option>
                `
            )
            .join("");

        $("offer-product").innerHTML =
            productOptions ||
            '<option value="">Nenhum produto cadastrado</option>';

        $("price-product").innerHTML =
            productOptions ||
            '<option value="">Nenhum produto cadastrado</option>';

        populateBrandSelector(
            "offer-product",
            "offer-brand"
        );

        populateBrandSelector(
            "price-product",
            "price-brand"
        );
    }

    function populateBrandSelector(
        productSelectId,
        brandSelectId
    ) {
        const products = getMyProducts();
        const select = $(productSelectId);
        const brandSelect = $(brandSelectId);
        const selected = products[Number(select.value)];

        if (!selected) {
            brandSelect.innerHTML =
                '<option value="">Nenhuma marca</option>';
            return;
        }

        brandSelect.innerHTML = `
            <option value="${escapeHTML(selected.id)}">
                ${escapeHTML(selected.marca)}
            </option>
        `;
    }

    function selectedProduct(productSelectId) {
        const products = getMyProducts();
        return products[Number($(productSelectId).value)] || null;
    }

    $("form-edit").onsubmit = async (event) => {
        event.preventDefault();

        const name = $("edit-nome").value.trim();
        const cnpj = $("edit-cnpj").value.trim();
        const address = $("edit-endereco").value.trim();
        const coordinates = $("edit-coord").value.trim();
        const opening = $("edit-abertura").value;
        const closing = $("edit-fechamento").value;
        const days = $("edit-dias").value
            .split(",")
            .map((day) => day.trim())
            .filter(Boolean);

        const valid =
            Boolean(name) &&
            Boolean(address) &&
            S.validateCNPJ(cnpj) &&
            S.isValidCoordinatePair(coordinates) &&
            Boolean(opening) &&
            Boolean(closing) &&
            days.length > 0;

        $("edit-cnpj-field").classList.toggle(
            "field-error",
            !S.validateCNPJ(cnpj)
        );

        if (!valid) {
            showMessage(
                "edit-alert",
                "Preencha nome, CNPJ, endereço, localização e horários corretamente.",
                "error"
            );
            $("edit-alert").classList.add("visible");
            return;
        }

        let logo = establishment.logo;
        let foto = establishment.foto;

        try {
            const newLogo = await readImage(
                $("edit-logo").files?.[0]
            );

            const newFoto = await readImage(
                $("edit-foto").files?.[0]
            );

            if (newLogo) {
                logo = newLogo;
            }

            if (newFoto) {
                foto = newFoto;
            }
        } catch (error) {
            showMessage(
                "edit-alert",
                error.message,
                "error"
            );
            $("edit-alert").classList.add("visible");
            return;
        }

        const updated = S.saveEstablishment({
            ...establishment,
            nome: name,
            cnpj: S.formatCNPJ(cnpj),
            endereco: address,
            coordenadas: coordinates,
            abertura: opening,
            fechamento: closing,
            dias: days,
            tipo: $("edit-tipo").value,
            logo,
            foto
        });

        Object.assign(establishment, updated);

        $("edit-logo").value = "";
        $("edit-foto").value = "";
        imagePreview = {};

        fillEstablishment();
        renderProducts();
        populateProductSelectors();
        renderSummary();
        renderCommerceRadar();

        showMessage(
            "edit-alert",
            "Dados atualizados com sucesso."
        );
        $("edit-alert").classList.add("visible");
    };

    $("view-public").onclick = () => {
        const target = `estabelecimento-publico.html?id=${encodeURIComponent(establishment.id)}`;
        window.location.assign(target);
    };

    $("new-product").onclick = () =>
        openProductForm();

    $("product-cancel").onclick = closeProductForm;

    $("product-form").onsubmit = (event) => {
        event.preventDefault();

        const name = $("product-name").value.trim();
        const brand = $("product-brand").value.trim();
        const category = $("product-category").value;
        const unit = $("product-unit").value.trim() || "unidade";
        const price = parseDecimal(
            $("product-price").value
        );
        const emoji = $("product-emoji").value.trim();
        const availability =
            $("product-availability").value;

        if (
            !name ||
            !brand ||
            !category ||
            !Number.isFinite(price) ||
            price < 0 ||
            !unit
        ) {
            showMessage(
                "product-msg",
                "Preencha nome, marca, categoria, unidade e um preço válido.",
                "error"
            );
            return;
        }

        const oldProduct = editingProduct;
        const isCatalogProduct =
            Boolean(oldProduct?.origemCatalogo);

        const product = {
            ...(oldProduct || {}),
            id:
                $("product-id").value ||
                (isCatalogProduct
                    ? undefined
                    : oldProduct?.id),
            estabelecimentoId: establishment.id,
            estabelecimento: establishment.nome,
            nome: name,
            marca: brand,
            categoria: category,
            unidade: unit,
            preco: price,
            emoji: emoji || "📦",
            disponibilidade: availability,
            chave: S.priceKey(
                name,
                brand,
                establishment.nome
            )
        };

        S.saveProduct(product);

        if (
            oldProduct &&
            getProductKey(oldProduct) !== product.chave
        ) {
            S.deleteProduct(
                oldProduct.id,
                oldProduct
            );
        }

        closeProductForm();
        renderProducts();
        populateProductSelectors();
        renderSummary();
        renderCommerceRadar();

        showMessage(
            "product-msg",
            "Produto salvo com sucesso."
        );
    };

    $("my-products").addEventListener(
        "click",
        (event) => {
            const quickPriceButton = event.target.closest("[data-quick-price]");
            if (quickPriceButton) {
                const product = getMyProducts().find((item) => String(item.id) === String(quickPriceButton.dataset.quickPrice));
                if (product) {
                    $("price-product").value = getMyProducts().indexOf(product);
                    populateBrandSelector("price-product", "price-brand");
                    $("price-value").value = String(product.preco ?? "").replace(".", ",");
                    $("price-value").focus();
                    $("price-form").scrollIntoView({ behavior: "smooth", block: "center" });
                }
                return;
            }

            const stockButton = event.target.closest("[data-toggle-stock]");
            if (stockButton) {
                const product = getMyProducts().find((item) => String(item.id) === String(stockButton.dataset.toggleStock));
                if (product) {
                    S.saveProduct({
                        ...product,
                        estabelecimentoId: establishment.id,
                        disponibilidade: product.disponibilidade === "esgotado" ? "disponivel" : "esgotado"
                    });
                    renderProducts();
                    renderSummary();
                    renderCommerceRadar();
                }
                return;
            }

            const editButton =
                event.target.closest(
                    "[data-edit-product]"
                );

            if (editButton) {
                const product = getMyProducts().find(
                    (item) =>
                        String(item.id) ===
                        String(
                            editButton.dataset.editProduct
                        )
                );

                if (product) {
                    openProductForm(product);
                }

                return;
            }

            const deleteButton =
                event.target.closest(
                    "[data-delete-product]"
                );

            if (deleteButton) {
                const product = getMyProducts().find(
                    (item) =>
                        String(item.id) ===
                        String(
                            deleteButton.dataset.deleteProduct
                        )
                );

                if (!product) {
                    return;
                }

                if (
                    !window.confirm(
                        `Excluir o produto "${product.nome}" deste estabelecimento?`
                    )
                ) {
                    return;
                }

                S.deleteProduct(
                    product.id,
                    product
                );

                renderProducts();
                populateProductSelectors();
                renderSummary();
            }
        }
    );

    $("offer-product").onchange = () =>
        populateBrandSelector(
            "offer-product",
            "offer-brand"
        );

    $("price-product").onchange = () =>
        populateBrandSelector(
            "price-product",
            "price-brand"
        );

    $("offer-form").onsubmit = (event) => {
        event.preventDefault();

        const product = selectedProduct(
            "offer-product"
        );
        const price = parseDecimal(
            $("offer-price").value
        );
        const end = $("offer-fim").value;

        if (
            !product ||
            !Number.isFinite(price) ||
            price < 0 ||
            !end
        ) {
            showMessage(
                "offer-msg",
                "Preencha produto, preço e validade da oferta.",
                "error"
            );
            return;
        }

        const key = getProductKey(product);

        S.saveOffer({
            chave: key,
            produto: product.nome,
            marca: product.marca,
            estabelecimento: establishment.nome,
            preco: price,
            inicio: new Date().toISOString(),
            fim: new Date(end).toISOString(),
            criadaPor: establishment.id
        });

        showMessage(
            "offer-msg",
            "Oferta publicada com sucesso."
        );

        $("offer-edit-key").value = "";
        $("offer-price").value = "";
        $("offer-fim").value = "";

        renderOffers();
        renderSummary();
        renderCommerceRadar();
    };

    $("offer-cancel").onclick = () => {
        $("offer-form").reset();
        $("offer-edit-key").value = "";
    };

    function renderOffers() {
        const offers =
            S.getOffersForEstablishment(
                establishment
            );

        if (!offers.length) {
            $("my-offers").innerHTML = `
                <div class="mutedBox">
                    Nenhuma oferta publicada por este estabelecimento.
                </div>
            `;
            return;
        }

        $("my-offers").innerHTML = offers
            .map(
                (offer) => `
                    <article class="dashboardListItem">
                        <div>
                            <strong>${escapeHTML(offer.produto)}</strong>
                            <small>
                                ${escapeHTML(offer.marca)}
                                · ${formatPrice(offer.preco)}
                            </small>
                            <small>
                                Válida até:
                                ${
                                    offer.fim
                                        ? new Intl.DateTimeFormat(
                                            "pt-BR",
                                            {
                                                dateStyle: "short",
                                                timeStyle: "short"
                                            }
                                        ).format(
                                            new Date(offer.fim)
                                        )
                                        : "sem prazo"
                                }
                            </small>
                        </div>

                        <div class="dashboardListActions">
                            <button
                                class="miniAction"
                                type="button"
                                data-edit-offer="${escapeHTML(offer.chave)}"
                            >
                                Editar
                            </button>

                            <button
                                class="miniAction dangerBtn"
                                type="button"
                                data-delete-offer="${escapeHTML(offer.chave)}"
                            >
                                Excluir
                            </button>
                        </div>
                    </article>
                `
            )
            .join("");
    }

    $("my-offers").addEventListener(
        "click",
        (event) => {
            const editButton =
                event.target.closest(
                    "[data-edit-offer]"
                );

            if (editButton) {
                const offer =
                    S.getOffersForEstablishment(
                        establishment
                    ).find(
                        (item) =>
                            item.chave ===
                            editButton.dataset.editOffer
                    );

                if (!offer) {
                    return;
                }

                const product = getMyProducts().find(
                    (item) =>
                        getProductKey(item) ===
                        offer.chave
                );

                if (product) {
                    $("offer-product").value =
                        getMyProducts().indexOf(product);

                    populateBrandSelector(
                        "offer-product",
                        "offer-brand"
                    );
                }

                $("offer-edit-key").value =
                    offer.chave;

                $("offer-price").value =
                    String(offer.preco).replace(".", ",");

                $("offer-fim").value =
                    offer.fim
                        ? new Date(offer.fim)
                            .toISOString()
                            .slice(0, 16)
                        : "";

                return;
            }

            const deleteButton =
                event.target.closest(
                    "[data-delete-offer]"
                );

            if (deleteButton) {
                if (
                    !window.confirm(
                        "Excluir esta oferta?"
                    )
                ) {
                    return;
                }

                S.deleteOffer(
                    deleteButton.dataset.deleteOffer,
                    establishment.id
                );

                renderOffers();
                renderSummary();
                renderCommerceRadar();
            }
        }
    );

    $("price-form").onsubmit = (event) => {
        event.preventDefault();

        const product = selectedProduct(
            "price-product"
        );
        const price = parseDecimal(
            $("price-value").value
        );

        if (
            !product ||
            !Number.isFinite(price) ||
            price < 0
        ) {
            showMessage(
                "price-msg",
                "Informe um preço válido.",
                "error"
            );
            return;
        }

        const updated = {
            ...product,
            preco: price
        };

        S.saveProduct({
            ...updated,
            id: product.origemCatalogo
                ? undefined
                : product.id,
            origemCatalogo: false,
            chave: getProductKey(product)
        });

        S.updatePrice(
            getProductKey(product),
            price,
            "atualização pelo estabelecimento"
        );

        showMessage(
            "price-msg",
            "Preço atualizado e histórico preservado."
        );

        $("price-value").value = "";

        renderProducts();
        populateProductSelectors();
        renderSummary();
        renderCommerceRadar();
    };

    [
        $("product-price"),
        $("offer-price"),
        $("price-value")
    ].forEach(setupDecimalInput);

    setupCNPJInput($("edit-cnpj"));
    setupCoordinateInput($("edit-coord"));

    const bindImagePreview = (inputId, kind) => {
        const input = $(inputId);
        if (!input) return;
        input.addEventListener("change", async () => {
            const file = input.files?.[0];
            if (!file) return;
            try {
                const data = await readImage(file);
                renderImages(kind === "logo" ? { logo: data } : { foto: data });
            } catch (error) {
                showMessage("edit-alert", error.message, "error");
                $("edit-alert")?.classList.add("visible");
            }
        });
    };

    bindImagePreview("edit-logo", "logo");
    bindImagePreview("edit-foto", "foto");

    fillEstablishment();
    renderProducts();
    populateProductSelectors();
    renderOffers();
    renderSummary();
    renderTrustSeal();
    renderCommerceRadar();

    document.addEventListener("santaBusca:serverReady", refreshDashboardData);
})();
