@echo off
cd /d "%~dp0"
start "Santa Busca - servidor" cmd /k "npm start"
timeout /t 3 /nobreak >nul
start "Santa Busca" "http://localhost:3000"
